<?php
    /* Sumaiya */
    $databaseURL = "https://attendance-system-6d7a6-default-rtdb.firebaseio.com/";

    /* Saurov */
    // $databaseURL = "https://attendance-system-9cb22-default-rtdb.firebaseio.com";
?>